This folder is used for example data, and it is not meant to be used for storing training data.

Follow steps to [Configure Training Data](../docs/custom_model.md#Configure-Custom-Training) to use your own data for training.